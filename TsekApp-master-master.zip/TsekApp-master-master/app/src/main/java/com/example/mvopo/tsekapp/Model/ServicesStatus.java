package com.example.mvopo.tsekapp.Model;

/**
 * Created by mvopo on 12/1/2017.
 */

public class ServicesStatus {
    public String name, group1, group2, group3, brgyId;

    public ServicesStatus(String name, String group1, String group2, String group3, String brgyId) {
        this.name = name;
        this.group1 = group1;
        this.group2 = group2;
        this.group3 = group3;
        this.brgyId = brgyId;
    }
}
