package com.example.mvopo.tsekapp.Model;

/**
 * Created by mvopo on 12/21/2017.
 */

public class FeedBack {
    public String id, subject, body;

    public FeedBack(String id, String subject, String body) {
        this.id = id;
        this.subject = subject;
        this.body = body;
    }
}
